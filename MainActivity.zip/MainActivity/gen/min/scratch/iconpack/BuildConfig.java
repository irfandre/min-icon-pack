/** Automatically generated file. DO NOT MODIFY */
package min.scratch.iconpack;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}